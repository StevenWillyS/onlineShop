<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>SIAPBELANJA</title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css'?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/font-awesome.css'?>">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/style1.css'?>">
	</head>
	<body>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">Siap Belanja</a>
			</div>	
			<?php echo form_open(base_url('cariIklan')); ?>
			<ul class="nav navbar-nav">
				<li><a href="<?php echo base_url('home'); ?>"><span class="fa fa-home"></span>Home</a></li>	
				<li style="width:400px;left:10px;top: 10px;"><input type="text" class="form-control" id="search" name="search"></li>
				<li style="top: 10px;left: 20px;"><button class="btn btn-primary" id="search_btn">Search</button></li>
			</ul>
			</form>
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-shopping-cart"></span>Cart <span class="badge">0</span></a>
					<div class="dropdown-menu" style="width: 400px;">
						<div class="panel panel-success">
							<div class ="panel-heading">
								<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in IDR</div>
								</div>	
							</div>
							<div class="panel-body"></div>
							<div class="panel-footer"></div>
						</div>
					</div>
				</li>
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-user"></span>SignIn</a>
					<ul class="dropdown-menu">
						<div style="width: 300px;">
							<div class="panel panel-primary">
								<div class="panel-heading">Login</div>
								<div class="panel-heading">
									<?php echo form_open('member/login'); ?>
									<label for="username">Username</label>
									<input type="text" class="form-control" id="username" name="username" required>
									<label for="password">Password</label>
									<input type="password" class="form-control" id="password" name="password" required>
									<p><br/></p>
									<input type="submit" class="btn btn-success" style="float: right;" id="login" value="Login">
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
				</li>
				<li><a href="<?php echo base_url('register')?>"><span class="fa fa-user"></span>SignUp</a></li>
			</ul>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<div id="container">
		<img src="<?php echo base_url('assets/img/gambar.png')?>">
	</div>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-2">
				<div id="get_category">
				</div>
				<div class="nav nav-pills bav-stacked">
					<li class="active"><a href="#"><h4>Categories<h4></a></li>
					<li><a onclick="loadKategori(this)" id="Alat-Olahraga">Alat Olahraga</a></li>
					<li><a onclick="loadKategori(this)" id="Elektronik">Elektronik</a></li>
					<li><a onclick="loadKategori(this)" id="Handphone-%26-Laptop">Handphone & laptop </a></li>
					<li><a onclick="loadKategori(this)" id="Kendaraan">Kendaraan</a></li>
					<li><a onclick="loadKategori(this)" id="Alat-Dapur">Alat Dapur</a></li>
				</div>
			</div>
			<div class="col-md-8">
				<div class="panel panel-info">
					<div class="panel-heading">Products<br>
					<?php if(isset($cari)) echo $cari; ?></div>
					<div class="panel-body" id="produk">
						<?php 
						foreach($iklan->result() as $data){ 
							$pic = explode(';',$data->Foto);
						?>
						<div class="col-md-4">
							<div class="panel panel-info">
								<div class="panel-heading"><?php echo $data->Judul; ?></div>
								<div class="panel-body">
									<img style="height: 300px; width: 100%;" src="<?php echo base_url().'assets/img/iklan/'.$pic[0]?>">
								</div>
								<div class="panel-heading">Rp <?php echo number_format($data->Harga,2,",","."); ?>
								<button style="float: right;" class="btn btn-danger btn-xs">AddToCart</button></div>
							</div>
						</div>
						<?php } ?>
					</div>
					<div class="panel-footer">&copy; 2017</div>
				</div>
			</div>
			<div class="col-md-1"></div>
		</div>
	</div>
		<script>
			function loadKategori(data){
				var url = "<?php echo base_url('home/kategori/'); ?>";  
				var id = data.id;
				$('#produk').load(url+id);
			}
		</script>
		<script src="<?php echo base_url().'assets/js/jquery-3.2.1.min.js'?>"></script>
		<script src="<?php echo base_url().'assets/js/bootstrap.min.js'?>"></script>
	</body>
</html>
<?php 
if(isset($_SESSION['notif'])){
	echo '<script>alert("'.$_SESSION['notif'].'")</script>';
	unset($_SESSION['notif']);
}
?>